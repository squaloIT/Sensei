
    <div id="wrapper">
        <div class="ja prvi">
            <img src="<?php echo $base_url; ?>images/ja.jpg" alt="picture of author" />
        </div>
       
        <div class="cetvrti">
            <h2 class="sensei naslov">Zovem se Nikola Mihajlovic</h2><br/>
            <p class="sensei text">Rođen sam 1994. godine u Beogradu. Osnovnu i srednju školu sam takodje završio u Beogradu. 
                Završio sam srednju elektrotehničku školu Nikola Tesla, smer multimedija.
                Trenutno studiram na visokoj ICT školi. Treca sam godina na smeru internet tehnologije. 
                Ovaj sajt je deo predispitnih obaveza iz predmeta web progamiranje PHP 2.<br/>
            
            Za backend je korišćen PHP-CodeIgniter Framework, a za frontend sopstveni CSS. Pored toga sam koristio JavaScript, jQuery kao i Ajax.</p>
        </div>
    </div>
</body>

