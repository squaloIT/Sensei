<footer>
   
		<div id="footer-content-wrapper">
				<div id="social-media" class="footer-part">
					<h3 class="footer-title sensei">Follow us</h3><br/><hr><br/><br/>
					<ul>
						<li><a href="https://www.facebook.com/"><img src="<?php echo $base_url; ?>images/face2.png"/></a></li>
						<li><a href="https://www.instagram.com/"><img src="<?php echo $base_url; ?>images/insta22.png"/></a></li>
					</ul>
					<ul>
						<li><a href="http://www.pinterest.com"><img src="<?php echo $base_url; ?>images/pin2.png"/></a></li>
						<li><a href="http://www.twitter.com"><img src="<?php echo $base_url; ?>images/tweet2.png"/></a></li>
					</ul>
				</div>
				
				<div class="footer-part">
					<h3 class="footer-title sensei">Contact us</h3><br/><hr><br/><br/>
					<ul>
						<li class="lista"><b class="sensei">Call:</b> +38111/ 3807-935 </li>
						<li class="lista"><b class="sensei">Call:</b> +38166/ 91-61-105 </li>
						<li  class="lista"><b class="sensei">Email:</b> <a href="mailto:sensei@gmail.com?Subject=Hello%20again" class="footer-link " target="_top">Sensei@gmail.com</a>
                                                </li>
						<li  class="lista"><b class="sensei">Skype:</b>&nbsp Funterest2014</li>
					</ul>
				</div>
				
				<div class="footer-part">
						<h3 class="footer-title boring sensei">Boring stuff</h3><br/><hr><br/><br/>
                                                <div><p class="footer-description">Copyright © 2016 We are Stay Safe Company | 
                                                        <a href="Autor" class="footer-link">Author United Brains ICT Students</a> of FUNTEREST.RS ALL RIGHTS RESERVED</p>
                                                </div>
					
				</div>
                                <div class="footer-part">
                                    <h3 class="footer-title boring sensei">Did you know?</h3><br/><hr><br/><br/>
                                        <div id="footer-part-anketa">
                                            <div class="footer-part-anketa-gornji">
                                                <p class='footer-description'><?php echo $anketa_podaci->tekst; ?></p>
                                            </div><br/>
                                            <div class="footer-part-anketa-donji">
                                                <a onclick="anketaAjax();return false;"><img src="<?php echo $base_url; ?>images/next2.png"/></a>
                                            </div>
                                           
                                        </div>
                                    
				</div>
		</div>
	</footer>
	
  </body>
</html>
