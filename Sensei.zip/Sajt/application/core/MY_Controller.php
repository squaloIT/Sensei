<?php


class MY_Controller extends CI_Controller{
    
    private $podaci=array();
    
    public function __construct() {
        
        parent::__construct();
        
        
        
    }
}
